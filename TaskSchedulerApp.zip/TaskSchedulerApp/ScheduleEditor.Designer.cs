﻿namespace TaskSchedulerApp
{
    partial class ScheduleEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges28 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges29 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges30 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            commandMacroPanel = new Panel();
            changeWallpaperWebButton = new Guna.UI2.WinForms.Guna2Button();
            changeWallpaperLocalButton = new Guna.UI2.WinForms.Guna2Button();
            sendToastButton = new Guna.UI2.WinForms.Guna2Button();
            sendEmailButton = new Guna.UI2.WinForms.Guna2Button();
            startProcessButton = new Guna.UI2.WinForms.Guna2Button();
            startWebUrlButton = new Guna.UI2.WinForms.Guna2Button();
            shutdownPcButton = new Guna.UI2.WinForms.Guna2Button();
            restartPcButton = new Guna.UI2.WinForms.Guna2Button();
            takeScreenshotButton = new Guna.UI2.WinForms.Guna2Button();
            addDelayButton = new Guna.UI2.WinForms.Guna2Button();
            guna2Separator1 = new Guna.UI2.WinForms.Guna2Separator();
            guna2TextBox1 = new Guna.UI2.WinForms.Guna2TextBox();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2NumericUpDown1 = new Guna.UI2.WinForms.Guna2NumericUpDown();
            guna2NumericUpDown2 = new Guna.UI2.WinForms.Guna2NumericUpDown();
            guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            ((System.ComponentModel.ISupportInitialize)guna2NumericUpDown1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)guna2NumericUpDown2).BeginInit();
            SuspendLayout();
            // 
            // commandMacroPanel
            // 
            commandMacroPanel.AutoScroll = true;
            commandMacroPanel.Dock = DockStyle.Left;
            commandMacroPanel.Location = new Point(0, 0);
            commandMacroPanel.Name = "commandMacroPanel";
            commandMacroPanel.Size = new Size(318, 697);
            commandMacroPanel.TabIndex = 0;
            // 
            // changeWallpaperWebButton
            // 
            changeWallpaperWebButton.BorderRadius = 8;
            changeWallpaperWebButton.CustomizableEdges = customizableEdges1;
            changeWallpaperWebButton.DisabledState.BorderColor = Color.DarkGray;
            changeWallpaperWebButton.DisabledState.CustomBorderColor = Color.DarkGray;
            changeWallpaperWebButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            changeWallpaperWebButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            changeWallpaperWebButton.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            changeWallpaperWebButton.ForeColor = Color.White;
            changeWallpaperWebButton.Location = new Point(326, 12);
            changeWallpaperWebButton.Name = "changeWallpaperWebButton";
            changeWallpaperWebButton.ShadowDecoration.CustomizableEdges = customizableEdges2;
            changeWallpaperWebButton.Size = new Size(120, 38);
            changeWallpaperWebButton.TabIndex = 1;
            changeWallpaperWebButton.Text = "Change Wallpaper Web";
            changeWallpaperWebButton.Click += changeWallpaperWebButton_Click;
            // 
            // changeWallpaperLocalButton
            // 
            changeWallpaperLocalButton.BorderRadius = 8;
            changeWallpaperLocalButton.CustomizableEdges = customizableEdges3;
            changeWallpaperLocalButton.DisabledState.BorderColor = Color.DarkGray;
            changeWallpaperLocalButton.DisabledState.CustomBorderColor = Color.DarkGray;
            changeWallpaperLocalButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            changeWallpaperLocalButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            changeWallpaperLocalButton.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            changeWallpaperLocalButton.ForeColor = Color.White;
            changeWallpaperLocalButton.Location = new Point(326, 56);
            changeWallpaperLocalButton.Name = "changeWallpaperLocalButton";
            changeWallpaperLocalButton.ShadowDecoration.CustomizableEdges = customizableEdges4;
            changeWallpaperLocalButton.Size = new Size(120, 38);
            changeWallpaperLocalButton.TabIndex = 2;
            changeWallpaperLocalButton.Text = "Change Wallpaper Local";
            changeWallpaperLocalButton.Click += changeWallpaperLocalButton_Click;
            // 
            // sendToastButton
            // 
            sendToastButton.BorderRadius = 8;
            sendToastButton.CustomizableEdges = customizableEdges5;
            sendToastButton.DisabledState.BorderColor = Color.DarkGray;
            sendToastButton.DisabledState.CustomBorderColor = Color.DarkGray;
            sendToastButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            sendToastButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            sendToastButton.FillColor = Color.DarkOliveGreen;
            sendToastButton.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            sendToastButton.ForeColor = Color.White;
            sendToastButton.Location = new Point(324, 144);
            sendToastButton.Name = "sendToastButton";
            sendToastButton.ShadowDecoration.CustomizableEdges = customizableEdges6;
            sendToastButton.Size = new Size(120, 38);
            sendToastButton.TabIndex = 4;
            sendToastButton.Text = "Send Toast";
            sendToastButton.Click += sendToastButton_Click;
            // 
            // sendEmailButton
            // 
            sendEmailButton.BorderRadius = 8;
            sendEmailButton.CustomizableEdges = customizableEdges7;
            sendEmailButton.DisabledState.BorderColor = Color.DarkGray;
            sendEmailButton.DisabledState.CustomBorderColor = Color.DarkGray;
            sendEmailButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            sendEmailButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            sendEmailButton.FillColor = Color.DarkOliveGreen;
            sendEmailButton.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            sendEmailButton.ForeColor = Color.White;
            sendEmailButton.Location = new Point(324, 100);
            sendEmailButton.Name = "sendEmailButton";
            sendEmailButton.ShadowDecoration.CustomizableEdges = customizableEdges8;
            sendEmailButton.Size = new Size(120, 38);
            sendEmailButton.TabIndex = 3;
            sendEmailButton.Text = "Send Email";
            sendEmailButton.Click += sendEmailButton_Click;
            // 
            // startProcessButton
            // 
            startProcessButton.BorderRadius = 8;
            startProcessButton.CustomizableEdges = customizableEdges9;
            startProcessButton.DisabledState.BorderColor = Color.DarkGray;
            startProcessButton.DisabledState.CustomBorderColor = Color.DarkGray;
            startProcessButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            startProcessButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            startProcessButton.FillColor = Color.Maroon;
            startProcessButton.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            startProcessButton.ForeColor = Color.White;
            startProcessButton.Location = new Point(326, 232);
            startProcessButton.Name = "startProcessButton";
            startProcessButton.ShadowDecoration.CustomizableEdges = customizableEdges10;
            startProcessButton.Size = new Size(120, 38);
            startProcessButton.TabIndex = 6;
            startProcessButton.Text = "Start Process";
            startProcessButton.Click += startProcessButton_Click;
            // 
            // startWebUrlButton
            // 
            startWebUrlButton.BorderRadius = 8;
            startWebUrlButton.CustomizableEdges = customizableEdges11;
            startWebUrlButton.DisabledState.BorderColor = Color.DarkGray;
            startWebUrlButton.DisabledState.CustomBorderColor = Color.DarkGray;
            startWebUrlButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            startWebUrlButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            startWebUrlButton.FillColor = Color.Maroon;
            startWebUrlButton.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            startWebUrlButton.ForeColor = Color.White;
            startWebUrlButton.Location = new Point(326, 188);
            startWebUrlButton.Name = "startWebUrlButton";
            startWebUrlButton.ShadowDecoration.CustomizableEdges = customizableEdges12;
            startWebUrlButton.Size = new Size(120, 38);
            startWebUrlButton.TabIndex = 5;
            startWebUrlButton.Text = "Start Web Url";
            startWebUrlButton.Click += startWebUrlButton_Click;
            // 
            // shutdownPcButton
            // 
            shutdownPcButton.BorderRadius = 8;
            shutdownPcButton.CustomizableEdges = customizableEdges13;
            shutdownPcButton.DisabledState.BorderColor = Color.DarkGray;
            shutdownPcButton.DisabledState.CustomBorderColor = Color.DarkGray;
            shutdownPcButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            shutdownPcButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            shutdownPcButton.FillColor = Color.DarkOrchid;
            shutdownPcButton.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            shutdownPcButton.ForeColor = Color.White;
            shutdownPcButton.Location = new Point(326, 320);
            shutdownPcButton.Name = "shutdownPcButton";
            shutdownPcButton.ShadowDecoration.CustomizableEdges = customizableEdges14;
            shutdownPcButton.Size = new Size(120, 38);
            shutdownPcButton.TabIndex = 8;
            shutdownPcButton.Text = "Shutdown PC";
            shutdownPcButton.Click += shutdownPcButton_Click;
            // 
            // restartPcButton
            // 
            restartPcButton.BorderRadius = 8;
            restartPcButton.CustomizableEdges = customizableEdges15;
            restartPcButton.DisabledState.BorderColor = Color.DarkGray;
            restartPcButton.DisabledState.CustomBorderColor = Color.DarkGray;
            restartPcButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            restartPcButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            restartPcButton.FillColor = Color.DarkOrchid;
            restartPcButton.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            restartPcButton.ForeColor = Color.White;
            restartPcButton.Location = new Point(326, 276);
            restartPcButton.Name = "restartPcButton";
            restartPcButton.ShadowDecoration.CustomizableEdges = customizableEdges16;
            restartPcButton.Size = new Size(120, 38);
            restartPcButton.TabIndex = 7;
            restartPcButton.Text = "Restart PC";
            restartPcButton.Click += restartPcButton_Click;
            // 
            // takeScreenshotButton
            // 
            takeScreenshotButton.BorderRadius = 8;
            takeScreenshotButton.CustomizableEdges = customizableEdges17;
            takeScreenshotButton.DisabledState.BorderColor = Color.DarkGray;
            takeScreenshotButton.DisabledState.CustomBorderColor = Color.DarkGray;
            takeScreenshotButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            takeScreenshotButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            takeScreenshotButton.FillColor = Color.DarkGoldenrod;
            takeScreenshotButton.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            takeScreenshotButton.ForeColor = Color.White;
            takeScreenshotButton.Location = new Point(326, 364);
            takeScreenshotButton.Name = "takeScreenshotButton";
            takeScreenshotButton.ShadowDecoration.CustomizableEdges = customizableEdges18;
            takeScreenshotButton.Size = new Size(120, 38);
            takeScreenshotButton.TabIndex = 9;
            takeScreenshotButton.Text = "Take Screenshot";
            takeScreenshotButton.Click += takeScreenshotButton_Click;
            // 
            // addDelayButton
            // 
            addDelayButton.BorderRadius = 8;
            addDelayButton.CustomizableEdges = customizableEdges19;
            addDelayButton.DisabledState.BorderColor = Color.DarkGray;
            addDelayButton.DisabledState.CustomBorderColor = Color.DarkGray;
            addDelayButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            addDelayButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            addDelayButton.FillColor = Color.FromArgb(64, 64, 64);
            addDelayButton.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            addDelayButton.ForeColor = Color.White;
            addDelayButton.Location = new Point(326, 408);
            addDelayButton.Name = "addDelayButton";
            addDelayButton.ShadowDecoration.CustomizableEdges = customizableEdges20;
            addDelayButton.Size = new Size(120, 38);
            addDelayButton.TabIndex = 10;
            addDelayButton.Text = "Add Delay";
            addDelayButton.Click += addDelayButton_Click;
            // 
            // guna2Separator1
            // 
            guna2Separator1.Location = new Point(326, 461);
            guna2Separator1.Name = "guna2Separator1";
            guna2Separator1.Size = new Size(120, 10);
            guna2Separator1.TabIndex = 11;
            // 
            // guna2TextBox1
            // 
            guna2TextBox1.BorderRadius = 4;
            guna2TextBox1.CustomizableEdges = customizableEdges21;
            guna2TextBox1.DefaultText = "";
            guna2TextBox1.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            guna2TextBox1.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            guna2TextBox1.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox1.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox1.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox1.Font = new Font("Segoe UI", 9F);
            guna2TextBox1.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox1.Location = new Point(326, 505);
            guna2TextBox1.Name = "guna2TextBox1";
            guna2TextBox1.PasswordChar = '\0';
            guna2TextBox1.PlaceholderText = "name";
            guna2TextBox1.SelectedText = "";
            guna2TextBox1.ShadowDecoration.CustomizableEdges = customizableEdges22;
            guna2TextBox1.Size = new Size(118, 23);
            guna2TextBox1.TabIndex = 12;
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.Transparent;
            guna2HtmlLabel1.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            guna2HtmlLabel1.ForeColor = Color.Silver;
            guna2HtmlLabel1.Location = new Point(327, 482);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(98, 19);
            guna2HtmlLabel1.TabIndex = 13;
            guna2HtmlLabel1.Text = "Schedule Name";
            // 
            // guna2HtmlLabel2
            // 
            guna2HtmlLabel2.BackColor = Color.Transparent;
            guna2HtmlLabel2.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            guna2HtmlLabel2.ForeColor = Color.Silver;
            guna2HtmlLabel2.Location = new Point(328, 546);
            guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            guna2HtmlLabel2.Size = new Size(93, 19);
            guna2HtmlLabel2.TabIndex = 14;
            guna2HtmlLabel2.Text = "Schedule Time";
            // 
            // guna2NumericUpDown1
            // 
            guna2NumericUpDown1.BackColor = Color.Transparent;
            guna2NumericUpDown1.BorderRadius = 4;
            guna2NumericUpDown1.BorderThickness = 0;
            guna2NumericUpDown1.CustomizableEdges = customizableEdges23;
            guna2NumericUpDown1.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            guna2NumericUpDown1.Location = new Point(326, 569);
            guna2NumericUpDown1.Maximum = new decimal(new int[] { 23, 0, 0, 0 });
            guna2NumericUpDown1.Name = "guna2NumericUpDown1";
            guna2NumericUpDown1.ShadowDecoration.CustomizableEdges = customizableEdges24;
            guna2NumericUpDown1.Size = new Size(55, 26);
            guna2NumericUpDown1.TabIndex = 15;
            // 
            // guna2NumericUpDown2
            // 
            guna2NumericUpDown2.BackColor = Color.Transparent;
            guna2NumericUpDown2.BorderRadius = 4;
            guna2NumericUpDown2.BorderThickness = 0;
            guna2NumericUpDown2.CustomizableEdges = customizableEdges25;
            guna2NumericUpDown2.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            guna2NumericUpDown2.Location = new Point(388, 569);
            guna2NumericUpDown2.Maximum = new decimal(new int[] { 59, 0, 0, 0 });
            guna2NumericUpDown2.Name = "guna2NumericUpDown2";
            guna2NumericUpDown2.ShadowDecoration.CustomizableEdges = customizableEdges26;
            guna2NumericUpDown2.Size = new Size(55, 26);
            guna2NumericUpDown2.TabIndex = 16;
            // 
            // guna2Button1
            // 
            guna2Button1.BorderRadius = 8;
            guna2Button1.CustomizableEdges = customizableEdges27;
            guna2Button1.DisabledState.BorderColor = Color.DarkGray;
            guna2Button1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button1.FillColor = Color.YellowGreen;
            guna2Button1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2Button1.ForeColor = Color.White;
            guna2Button1.Location = new Point(333, 659);
            guna2Button1.Name = "guna2Button1";
            guna2Button1.ShadowDecoration.CustomizableEdges = customizableEdges28;
            guna2Button1.Size = new Size(106, 26);
            guna2Button1.TabIndex = 17;
            guna2Button1.Text = "Save && Exit";
            guna2Button1.Click += saveAndExit_Click;
            // 
            // guna2Button2
            // 
            guna2Button2.BorderRadius = 8;
            guna2Button2.CustomizableEdges = customizableEdges29;
            guna2Button2.DisabledState.BorderColor = Color.DarkGray;
            guna2Button2.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button2.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button2.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button2.FillColor = Color.DarkRed;
            guna2Button2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2Button2.ForeColor = Color.White;
            guna2Button2.Location = new Point(333, 627);
            guna2Button2.Name = "guna2Button2";
            guna2Button2.ShadowDecoration.CustomizableEdges = customizableEdges30;
            guna2Button2.Size = new Size(106, 26);
            guna2Button2.TabIndex = 18;
            guna2Button2.Text = "Exit";
            guna2Button2.Click += exit_Click;
            // 
            // ScheduleEditor
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.FromArgb(24, 24, 24);
            ClientSize = new Size(456, 697);
            Controls.Add(guna2Button2);
            Controls.Add(guna2Button1);
            Controls.Add(guna2NumericUpDown2);
            Controls.Add(guna2NumericUpDown1);
            Controls.Add(guna2HtmlLabel2);
            Controls.Add(guna2HtmlLabel1);
            Controls.Add(guna2TextBox1);
            Controls.Add(guna2Separator1);
            Controls.Add(addDelayButton);
            Controls.Add(takeScreenshotButton);
            Controls.Add(shutdownPcButton);
            Controls.Add(restartPcButton);
            Controls.Add(startProcessButton);
            Controls.Add(startWebUrlButton);
            Controls.Add(sendToastButton);
            Controls.Add(sendEmailButton);
            Controls.Add(changeWallpaperLocalButton);
            Controls.Add(changeWallpaperWebButton);
            Controls.Add(commandMacroPanel);
            Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            ForeColor = Color.Silver;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Name = "ScheduleEditor";
            Text = "Schedule Editor";
            ((System.ComponentModel.ISupportInitialize)guna2NumericUpDown1).EndInit();
            ((System.ComponentModel.ISupportInitialize)guna2NumericUpDown2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel commandMacroPanel;
        private Guna.UI2.WinForms.Guna2Button changeWallpaperWebButton;
        private Guna.UI2.WinForms.Guna2Button changeWallpaperLocalButton;
        private Guna.UI2.WinForms.Guna2Button sendToastButton;
        private Guna.UI2.WinForms.Guna2Button sendEmailButton;
        private Guna.UI2.WinForms.Guna2Button startProcessButton;
        private Guna.UI2.WinForms.Guna2Button startWebUrlButton;
        private Guna.UI2.WinForms.Guna2Button shutdownPcButton;
        private Guna.UI2.WinForms.Guna2Button restartPcButton;
        private Guna.UI2.WinForms.Guna2Button takeScreenshotButton;
        private Guna.UI2.WinForms.Guna2Button addDelayButton;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator1;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2NumericUpDown guna2NumericUpDown1;
        private Guna.UI2.WinForms.Guna2NumericUpDown guna2NumericUpDown2;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
    }
}