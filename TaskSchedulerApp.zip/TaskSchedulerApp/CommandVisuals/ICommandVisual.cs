﻿namespace TaskSchedulerApp.CommandVisuals
{
    public interface ICommandVisual
    {
        ITaskCommand GetCommand();
    }
}
